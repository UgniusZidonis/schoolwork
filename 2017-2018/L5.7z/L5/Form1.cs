﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L5 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        const string IN1 = "..\\..\\U11a.txt";
        const string IN2 = "..\\..\\U11b.txt";
        const string OUT = "..\\..\\Output.txt";

        List<Komanda<Zaidejas>> komandos = new List<Komanda<Zaidejas>>();
        List<Zaidejas> best_centr = new List<Zaidejas>();
        List<Zaidejas> best_puol = new List<Zaidejas>();
        List<Zaidejas> best_gyn = new List<Zaidejas>();

        void Input1() {
            using (StreamReader sr = new StreamReader(IN1)) {
                List<Zaidejas> a = new List<Zaidejas>();

                string line;
                while ((line = sr.ReadLine()) != null) {
                    string[] parts = line.Split(' ');

                    a.Add(new Zaidejas(parts[0], parts[1]+" "+parts[2], parts[3], int.Parse(parts[4]), parts[5], int.Parse(parts[6]), int.Parse(parts[7])));
                }

                foreach (var i in komandos) {
                    foreach (var j in a)
                        if (i.komanda.Equals(j.komanda)) {
                            i.zaidejai.Add(j);
                        }
            }
            }

            
        }

        void Input2() {
            using (StreamReader sr = new StreamReader(IN2)) {
                string line;
                while ((line = sr.ReadLine()) != null) {
                    string[] parts = line.Split(' ');

                    komandos.Add(new Komanda<Zaidejas>(parts[0], int.Parse(parts[1]), int.Parse(parts[2])));
                }
            }
        }

        List<Zaidejas> BestPlayers(string poz) {
            List<Zaidejas> ret = new List<Zaidejas>();

            foreach (var i in komandos) {
                foreach (var j in i.zaidejai) {
                    if (j.pozicija == poz)
                        ret.Add(j);
                }
            }

            ret.Sort();

            return ret;
        }

        Komanda<Zaidejas> Best(List<Komanda<Zaidejas>> a) {
            int max = 0;

            for (int i = 0; i < a.Count; i++)
                if (a[i].laimeta > a[max].laimeta)
                    max = i;

            return a[max];
        }

        List<Komanda<Zaidejas>> BestList(List<Komanda<Zaidejas>> a) {
            List<Komanda<Zaidejas>> ret = new List<Komanda<Zaidejas>>();

            int max = a[0].laimeta;

            for (int i = 0; i < a.Count; i++)
                if (a[i].laimeta > max)
                    max = a[i].laimeta;

            foreach (var i in a)
                if (i.laimeta == max)
                    ret.Add(i);

            return ret;
        }

        List<int> Vieta(Komanda<Zaidejas> z) {
            List<int> ret = new List<int>();

            foreach (var i in z.zaidejai) {
                switch (i.pozicija) {
                    case "Centras":
                        ret.Add(best_centr.IndexOf(i));
                        break;
                    case "Puolejas":
                        ret.Add(best_puol.IndexOf(i));
                        break;
                    case "Gynejas":
                        ret.Add(best_gyn.IndexOf(i));
                        break;
                }
            }

            return ret;
        }

        void newmaker(List<Zaidejas> grupe, string pav) {
            TabPage puslapis = new TabPage(pav);
            tabControl1.TabPages.Add(puslapis);
            FlowLayoutPanel skydelis = new FlowLayoutPanel();
            skydelis.Dock = DockStyle.Fill;
            skydelis.FlowDirection = FlowDirection.TopDown;
            puslapis.Controls.Add(skydelis);
            

            //TODO vėliau studentų sąrašo atvaizdavimą pridėsime čia
            DataGridView tinklelis = new DataGridView();
            tinklelis.AutoGenerateColumns = false;
            tinklelis.RowHeadersVisible = false;
            tinklelis.AllowUserToAddRows = false;
            tinklelis.AllowUserToDeleteRows = false;
            tinklelis.AutoSize = true;
            tinklelis.BackgroundColor = Color.White;
            BindingSource duomenuModelis = new BindingSource();
            foreach (var s in grupe) {
                duomenuModelis.Add(s);
            }
            //kiekvienas studento objektas atitiks vieną eilutę tinklelyje
            tinklelis.DataSource = duomenuModelis;
            //apsirašom tinklelio stulpelius
            DataGridViewColumn column = new DataGridViewTextBoxColumn();

            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "vieta";
            column.Name = "Vieta";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "var_pav";
            column.Name = "Vardas Pavarde";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);
  
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "gim_met";
            column.Name = "Gimimo metai";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "ugis";
            column.Name = "Ugis";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "pozicija";
            column.Name = "Pozicija";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "rungt";
            column.Name = "Zaistos rungt.";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "taskai";
            column.Name = "Imesti taskai";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);


            skydelis.Controls.Add(tinklelis);
            puslapis.Refresh();
        }

        void maker(Komanda<Zaidejas> grupe, bool is_best) {
            List<int> vietos = Vieta(grupe);

            for (int i = 0; i < grupe.zaidejai.Count; i++) {
                grupe.zaidejai[i].vieta = vietos[i] + 1;
            }

            TabPage puslapis = new TabPage(grupe.komanda);
            tabControl1.TabPages.Add(puslapis);
            FlowLayoutPanel skydelis = new FlowLayoutPanel();
            skydelis.Dock = DockStyle.Fill;
            skydelis.FlowDirection = FlowDirection.TopDown;
            puslapis.Controls.Add(skydelis);
            Label kursas = new Label();
            kursas.Text = "Zaistos rungtynes: " + grupe.zaistos_rungt;
            kursas.AutoSize = true;
            skydelis.Controls.Add(kursas);
            Label specializacija = new Label();
            specializacija.Text = "Laimetos rungtynes: " + grupe.laimeta;
            specializacija.AutoSize = true;
            skydelis.Controls.Add(specializacija);
            if (is_best) {
                Label a = new Label();
                a.Text = "Si komanda geriausia";
                a.AutoSize = true;
                skydelis.Controls.Add(a);
            }
  
            //TODO vėliau studentų sąrašo atvaizdavimą pridėsime čia
            DataGridView tinklelis = new DataGridView();
            tinklelis.AutoGenerateColumns = false;
            tinklelis.RowHeadersVisible = false;
            tinklelis.AllowUserToAddRows = false;
            tinklelis.AllowUserToDeleteRows = false;
            tinklelis.AutoSize = true;
            tinklelis.BackgroundColor = Color.White;
            BindingSource duomenuModelis = new BindingSource();
            foreach (var s in grupe.zaidejai) {
                duomenuModelis.Add(s);
            }
            //kiekvienas studento objektas atitiks vieną eilutę tinklelyje
            tinklelis.DataSource = duomenuModelis;
            //apsirašom tinklelio stulpelius
            DataGridViewColumn column = new DataGridViewTextBoxColumn();
     
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "var_pav";
            column.Name = "Vardas Pavarde";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);
 
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "gim_met";
            column.Name = "Gimimo metai";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "ugis";
            column.Name = "Ugis";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "pozicija";
            column.Name = "Pozicija";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "rungt";
            column.Name = "Zaistos rungt.";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "taskai";
            column.Name = "Imesti taskai";
            column.ReadOnly = true;
            tinklelis.Columns.Add(column);

            if (is_best) {
                column = new DataGridViewTextBoxColumn();
                column.DataPropertyName = "vieta";
                column.Name = "Vieta pozicijoje";
                column.ReadOnly = true;
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                tinklelis.Columns.Add(column);
            }

            skydelis.Controls.Add(tinklelis);
            puslapis.Refresh();
        }

        private void ivestiToolStripMenuItem_Click(object sender, EventArgs e) {
            Input2();
            Input1();

            best_centr = BestPlayers("Centras");
            best_puol = BestPlayers("Puolejas");
            best_gyn = BestPlayers("Gynejas");

            newmaker(best_centr, "Centras");
            newmaker(best_puol, "Puolejas");
            newmaker(best_gyn, "Gynejas");

            List<Komanda<Zaidejas>> temp = new List<Komanda<Zaidejas>>(komandos);
            List<Komanda<Zaidejas>> best = BestList(temp);
            foreach (var i in best) {
                maker(i, true);
                temp.Remove(i);
            }
            foreach (var i in temp)
                maker(i, false);
        }

        private void baigtiToolStripMenuItem_Click(object sender, EventArgs e) {
            Close();
        }
    }
}
