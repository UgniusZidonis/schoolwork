﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5 {
    class Komanda<T> where T : Zaidejas {
        public string komanda { get; set; }
        public int zaistos_rungt { get; set; }
        public int laimeta { get; set; }
        public List<T> zaidejai = new List<T>();

        public Komanda(string komanda, int zaistos_rungt, int laim) {
            this.komanda = komanda;
            this.zaistos_rungt = zaistos_rungt;
            laimeta = laim;
        }
    }
}
