﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5 {
    class Zaidejas : IComparable<Zaidejas> {
        public string komanda { get; set; }
        public string var_pav { get; set; }
        public string gim_met { get; set; }
        public int ugis { get; set; }
        public string pozicija { get; set; }
        public int rungt { get; set; }
        public int taskai { get; set; }

        public int vieta { get; set; }

        public Zaidejas(string kom, string varp, string gim, int ugis, string poz, int rungt, int task) {
            komanda = kom;
            var_pav = varp;
            gim_met = gim;
            this.ugis = ugis;
            taskai = task;
            pozicija = poz;
            this.rungt = rungt;
        }

        public int CompareTo(Zaidejas other) {
            if (taskai == other.taskai && rungt == other.rungt)
                return 0;
            else if (taskai > other.taskai || (taskai == other.taskai && rungt > other.rungt))
                return -1;
            else
                return 1;
        }
    }
}
