﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Kepykla
{
    class Kepykla
    {
        private string kepykla;
        private string pav, miltai;
        private int rupumas, prieaugis;
        private double svoris;

        public Kepykla(string Kepyklos_pavadinimas, string kepinio_pavadinimas, string miltų_pavadinimas, int rupumas, int prieaugis, double svoris) {
            this.kepykla = Kepyklos_pavadinimas;
            this.pav = kepinio_pavadinimas;
            this.miltai = miltų_pavadinimas;
            this.rupumas = rupumas;
            this.prieaugis = prieaugis;
            this.svoris = svoris;
        }

        public string getKepykla() { return kepykla; }
        public string getName() { return pav; }
        public string getMiltai() { return miltai; }
        public int getRupumas() { return rupumas; }
        public int getPrieaugis() { return prieaugis; }
        public double getSvoris() { return svoris; }
    }

    class Program
    {
        static int CFn = 100;
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            const string CFin1 = "../../input1.txt";
            const string CFin2 = "../../input2.txt";

            Kepykla[] K1 = new Kepykla[CFn];
            int n1;
            int rupumas_count1;
            int prieaugis_count1;

            Kepykla[] K2 = new Kepykla[CFn];
            int n2;
            int rupumas_count2;
            int prieaugis_count2;

            Kepykla[] Bendras;
            int n;

            ReadFromFile(CFin1, K1, out n1);
            rupumas_count1 = SkaičiuotiNerupiausius(K1, n1);
            prieaugis_count1 = SkaičiuotiPrieaugius(K1, n1);

            ReadFromFile(CFin2, K2, out n2);
            rupumas_count2 = SkaičiuotiNerupiausius(K2, n2);
            prieaugis_count2 = SkaičiuotiPrieaugius(K2, n2);

            Bendras = VidutinioSvorioRinkinys(K1, K2, n1, n2, out n);

            Console.WriteLine("{0} kepykla:", K1[0].getKepykla());
            SpausdintiNerupiausius(K1, n1, rupumas_count1);
            SpausdintiPrieaugius(K1, n1, prieaugis_count1);

            Console.WriteLine("\n{0} kepykla:", K2[0].getKepykla());
            SpausdintiNerupiausius(K2, n2, rupumas_count2);
            SpausdintiPrieaugius(K2, n2, prieaugis_count2);

            Console.WriteLine();
            SpausdintiKurDidžiausiasPrieaugis(K1, K2, n1, n2);

            Console.WriteLine();
            SpausdintiBendrus(Bendras, n);


            /*---*/
            Console.WriteLine("\n\nPrograma baigė darbą!");
        }

        static void ReadFromFile(string fv, Kepykla[] K, out int n) {
            n = 0;
            string Kepykla;
            using (StreamReader reader = new StreamReader(fv)) {
                Kepykla = reader.ReadLine();
                string line;
                string[] parts;

                while ((line = reader.ReadLine()) != null) {
                    parts = line.Split(';');

                    K[n] = new Kepykla(Kepykla, parts[0], parts[1], int.Parse(parts[2]), int.Parse(parts[4]), double.Parse(parts[3]));
                    n++;
                }
            }
        }

        static int MažiausiasRupumas(Kepykla[] K, int n) {
            int a = K[0].getRupumas();

            for (int i = 1; i < n; i++) {
                if (a > K[i].getRupumas())
                    a = K[i].getRupumas();
            }

            return a;
        }

        static int SkaičiuotiNerupiausius(Kepykla[] K, int n) {
            int count = 0;
            int rupumas = MažiausiasRupumas(K, n);

            for (int i = 0; i < n; i++) {
                if (K[i].getRupumas() == rupumas)
                    count++;
            }

            return count;
        }

        static void SpausdintiNerupiausius(Kepykla[] K, int n, int count) {
            int rupumas = MažiausiasRupumas(K, n);
            Console.Write("Nerupiausi kepiniai: ");
            for (int i = 0; i < n; i++) {
                if (K[i].getRupumas() == rupumas)
                {
                    if (count == 1)
                        Console.WriteLine("{0} ({1,1:d}).", K[i].getName(), K[i].getRupumas());
                    else
                        Console.Write("{0} ({1,1:d}), ", K[i].getName(), K[i].getRupumas());

                    count--;
                }
            }
        }

        static int DidžiausiasPrieaugis(Kepykla[] K, int n) {
            int a = K[0].getPrieaugis();

            for (int i = 1; i < n; i++) {
                if (a < K[i].getPrieaugis())
                    a = K[i].getPrieaugis();
            }

            return a;
        }

        static int SkaičiuotiPrieaugius(Kepykla[] K, int n) {
            int count = 0;
            int prieaugis = DidžiausiasPrieaugis(K, n);

            for (int i = 0; i < n; i++) {
                if (K[i].getPrieaugis() == prieaugis)
                    count++;
            }

            return count;
        }

        static void SpausdintiPrieaugius(Kepykla[] K, int n, int count) {
            int prieaugis = DidžiausiasPrieaugis(K, n);
            Console.Write("Didžiausio prieaugio kepiniai: ");
            for (int i = 0; i < n; i++)
            {
                if (K[i].getPrieaugis() == prieaugis)
                {
                    if (count == 1)
                        Console.WriteLine("{0} ({1,1:d}%).", K[i].getName(), K[i].getPrieaugis());
                    else
                        Console.Write("{0} ({1,1:d}%), ", K[i].getName(), K[i].getPrieaugis());

                    count--;
                }
            }
        }

        static int RastiKurDidžiausiasPrieaugis(Kepykla[] K1, Kepykla[] K2, int n1, int n2) {
            int prieaugis1 = DidžiausiasPrieaugis(K1, n1);
            int prieaugis2 = DidžiausiasPrieaugis(K2, n2);

            if (prieaugis1 > prieaugis2)
                return 1;
            else if (prieaugis2 > prieaugis1)
                return 2;
            else
                return -1;
        }

        static void SpausdintiKurDidžiausiasPrieaugis(Kepykla[] K1, Kepykla[] K2, int n1, int n2)
        {
            int kur = RastiKurDidžiausiasPrieaugis(K1, K2, n1, n2);

            Console.Write("Didžiausio prieaugio kepinys yra ");

            if (kur != -1){
                if (kur == 1)
                    Console.WriteLine("pirmoje kepykloje");
                if (kur == 2)
                    Console.WriteLine("antroje kepykloje");
            }
            else
                Console.WriteLine("abiejose kepyklose");
        }

        static double VidutinisSvoris(Kepykla[] K1, int n1, Kepykla[] K2, int n2) {
            double svoris = 0;

            for (int i = 0; i < n1; i++)
                svoris += K1[i].getSvoris();

            for (int i = 0; i < n2; i++)
                svoris += K2[i].getSvoris();


            return svoris / ((double)n1 + (double)n2);
        }

        static int SkaičiuotiVidutinioSvorio(Kepykla[] K1, int n1, Kepykla[] K2, int n2) {
            int count = 0;
            double VidSvoris = VidutinisSvoris(K1, n1, K2, n2);

            for (int i = 0; i < n1; i++)
                if (K1[i].getSvoris() >= VidSvoris - VidSvoris / 10 && K1[i].getSvoris() <= VidSvoris + VidSvoris / 10)
                    count++;

            for (int i = 0; i < n2; i++)
                if (K2[i].getSvoris() >= VidSvoris - VidSvoris / 10 && K2[i].getSvoris() <= VidSvoris + VidSvoris / 10)
                    count++;

            return count;
        }

        static Kepykla[] VidutinioSvorioRinkinys(Kepykla[] K1, Kepykla[] K2, int n1, int n2, out int n) {
            int m = SkaičiuotiVidutinioSvorio(K1, n1, K2, n2);
            double VidSvoris = VidutinisSvoris(K1, n1, K2, n2);

            Kepykla[] K = new Kepykla[CFn];
            n = 0;

            for (int i = 0; i < n1; i++) {
                if (K1[i].getSvoris() >= VidSvoris - VidSvoris / 10 && K1[i].getSvoris() <= VidSvoris + VidSvoris / 10) {
                    K[n] = K1[i];
                    n++;
                }
            }

            for (int i = 0; i < n2; i++) {
                if (K2[i].getSvoris() >= VidSvoris - VidSvoris / 10 && K2[i].getSvoris() <= VidSvoris + VidSvoris / 10) {
                    K[n] = K2[i];
                    n++;
                }
            }

            Console.WriteLine(VidSvoris);

            return K;
        }

        static void SpausdintiBendrus(Kepykla[] K, int n) {
            const string viršus =
                "|-----------------------------------------------|\r\n" +
                "|             |         |           |           |\r\n" +
                "| Pavadinimas | Rupumas | Prieaugis |   Svoris  |\r\n" +
                "|             |         |           |           |\r\n" +
                "|-----------------------------------------------|";

            if (n != 0)
            {
                Console.WriteLine(viršus);

                for (int i = 0; i < n; i++)
                {
                    Console.WriteLine("|   {0,7}   |{1,5:d}    | {2,5:d}     | {3,7:f2}   |", K[i].getName(), K[i].getRupumas(), K[i].getPrieaugis(), K[i].getSvoris());
                }

                Console.WriteLine("-------------------------------------------------");
            }

            else
                Console.WriteLine("Bendro sąrašo nėra");
        }
    }
}
