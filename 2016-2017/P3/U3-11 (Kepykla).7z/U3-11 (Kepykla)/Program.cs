﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace U3_11__Kepykla_
{
    /*
     
     * * KEPYKLOS PAVADINIMAS KARTOTIS GALI
     * * KEPYKLOS PAVADINIMAS KARTOTIS GALI
     * * KEPYKLOS PAVADINIMAS KARTOTIS GALI
     * * KEPYKLOS PAVADINIMAS KARTOTIS GALI
     
    */
    class Kepykla
    {
        private string name;
        private string[] pavadinimas, miltai;
        private int[] rupumas, prieaugis;
        private double[] svoris;

        public Kepykla(string name, string[] pavadinimas, string[] miltai, int[] rupumas, double[] svoris, int[] prieaugis) {
            this.name = name;
            this.pavadinimas = pavadinimas;
            this.miltai = miltai;
            this.rupumas = rupumas;
            this.svoris = svoris;
            this.prieaugis = prieaugis;
        }

        public string getKepyklaName() { return name; }
        public string getName(int i) { return pavadinimas[i]; }
        public string getMiltai(int i) { return miltai[i]; }
        public int getRupumas(int i) { return rupumas[i]; }
        public double getSvoris(int i) { return svoris[i]; }
        public int getPrieaugis(int i) { return prieaugis[i]; }
    }

    class Program
    {
        static int CFn = 100;

        static void Main(string[] args)
        {
            const string CFin = "...\\...\\input.txt";

            Kepykla Kepykla;
            string KepyklaName;
            string[] name, miltai;
            int[] rupumas, prieaugis;
            double[] svoris;
            int n;

            ReadFromFile(CFin, out KepyklaName, out name, out miltai, out rupumas, out svoris, out prieaugis, out n);
            Kepykla = new Kepykla(KepyklaName, name, miltai, rupumas, svoris, prieaugis);
        }

        static void ReadFromFile(string fv, out string KepyklaName, out string[] name, out string[] miltai, out int[] rupumas, out double[] svoris, out int[] prieaugis, out int n) {
            name = new string[CFn];
            miltai = new string[CFn];
            rupumas = new int[CFn];
            svoris = new double[CFn];
            prieaugis = new int[CFn];
            n = 0;

            using (StreamReader reader = new StreamReader(fv)) {
                KepyklaName = reader.ReadLine();
                string line;
                string[] parts;

                while ((line = reader.ReadLine()) != null && n < CFn)
                {
                    parts = line.Split(';');
                    name[n] = parts[0];
                    miltai[n] = parts[1];
                    rupumas[n] = int.Parse(parts[2]);
                    svoris[n] = double.Parse(parts[3]);
                    prieaugis[n] = int.Parse(parts[4]);
                    n++;
                }
            }
        }

        static void ReadFromConsole(out string KepyklaName, out string[] name, out string[] miltai, out int[] rupumas, out double[] svoris, out int[] prieaugis, out int n) {
            name = new string[CFn];
            miltai = new string[CFn];
            rupumas = new int[CFn];
            svoris = new double[CFn];
            prieaugis = new int[CFn];

            Console.Write("Įveskite kepyklos pavadinimą: ");
            KepyklaName = Console.ReadLine();

            Console.Write("\nĮveskite kepinių kiekį: ");
            n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++) {
                Console.Clear();

                Console.Write("Įveskite kepinio pavadinimą: ");
                name[i] = Console.ReadLine();
                Console.Write("Įveskite miltų pavadinimą: ");
                miltai[i] = Console.ReadLine();
                Console.Write("Įveskite kepinio rupumą: ");
                rupumas[i] = int.Parse(Console.ReadLine());
                Console.Write("Įveskite kepaliuko svorį: ");
                svoris[i] = double.Parse(Console.ReadLine());
                Console.Write("Įveskite kepinio prieaugį: ");
                prieaugis[i] = int.Parse(Console.ReadLine());

            }
        }
    }
}
